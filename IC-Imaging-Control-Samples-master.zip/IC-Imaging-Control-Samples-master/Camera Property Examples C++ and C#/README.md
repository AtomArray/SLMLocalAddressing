# Camera Property Examples in C# and C++

In this directory are some common sample source codes for controlling camera properties using the IC Imaging Control 
VCD Property interface.
 
Lens Control

[This](https://github.com/TheImagingSource/IC-Imaging-Control-Samples/tree/master/Camera%20Property%20Examples%20C%2B%2B%20and%20C%23/Lens%20Control%20Auto%20Focus%2C%20Focus%20and%20Zoom#lens-control) sample code implemens Auto Focus One Push, Focus and Zoom.
