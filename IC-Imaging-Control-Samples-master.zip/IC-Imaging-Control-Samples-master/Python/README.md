# Python samples for Windows

## Open Camera, Grab Image to OpenCV, callbacks
These sample show, how to open a camera, get iamge data, handle them with OpenCV and how to use callbacks.
